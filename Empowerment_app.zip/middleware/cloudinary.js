const cloudinary = require('cloudinary').v2
cloudinary.config({
  cloud_name:  "dtflqvihf",
  api_key:  "615143145848663",
  api_secret:  "QhfMEGNvcHmZGcColLNNIg1fTMc",
});
module.exports = cloudinary;

